# Import modules
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import split
import shutil
import re
import pandas as pd

# Create a spark session
spark = SparkContext("local", "myApp")

# Create a function to validate whether a given string represents a valid IP address
def is_ip(line):
    words = line.split(" ")
    ip_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    return ip_pattern.match(words[0]) is not None
    
# Create a function to verify if the last column in a line is an integer
def is_int(line):
# Utilize a regular expression to match one or more digits at the end of a line
  pattern = r"\d+$"
  return bool(re.search(pattern, line))

# Extract the first word as the key, the last word as the value, and convert it to an integer
def get_key_and_value(line):
# Split the line by spaces and retrieve the first and last elements as strings
  words = line.split(" ")
  key = words[0]
  value = words[-1]
# Attempt to convert the last element to an integer, and if unsuccessful, return None
  try:
    value = int(value)
  except ValueError:
    value = None
# Return key and value
  return (key, value)

# Read the file and create RDD
log = spark.textFile("epa-http.txt")

# Filter
ipLog = log.filter(is_ip)

filteredLog = ipLog.filter(is_int)

# Map the RDD to extract the key (IP) and value (Bytes)
key_value = filteredLog.map(get_key_and_value)

# Sum the Bytes transmitted for each unique IP address
sum_bytes = key_value.reduceByKey(lambda x, y: x + y)

# Sort the RDD by key in string ascending order
final_rdd = sum_bytes.sortByKey(ascending=True)

# Remove the current output directory if it already exists
output_directory = './HW1_1.csv'
try:
    shutil.rmtree(output_directory)
except FileNotFoundError:
    pass

# create a data frame first and save it as csv file.
a = final_rdd.map(lambda x: x[0]).collect()
b = final_rdd.map(lambda x: x[1]).collect()
dataframe = pd.DataFrame({'IP':a, 'Bytes':b})
dataframe.to_csv("Q1.csv",index=False,sep=',')

spark.stop()
