from pyspark import SparkContext
from pyspark.sql import SparkSession

from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType, ArrayType, LongType
from pyspark.streaming import StreamingContext
import time
from pyspark.sql.functions import to_timestamp, col, current_timestamp, date_sub, lit, unix_timestamp, expr, regexp_extract, when, regexp_replace, window, array, explode
import requests
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib import cm
import pandas as pd
import numpy as np
import csv
from streamSubFunctions import *
from collections import Counter
import threading
import os

time_range_titles = {
    "week": "Week",
    "month": "Month",
    "half_year": "Half Year"
}



def file_watchdog(file_path):
    # Monitor the file for changes
    file_modification_time = os.path.getmtime(file_path)
    while True:
        current_modification_time = os.path.getmtime(file_path)
        if current_modification_time != file_modification_time:
            # File has been modified
            print("Triggered!")
            save_json_to_file(call_emby_api(emby_date_shifted()), './data/emby_data_03.json')
            file_modification_time = current_modification_time
        time.sleep(1)  # Check every second



def emby_monitor():
    while True:
        next_file_name = get_next_file_name('./data/')
        data = call_emby_api(emby_date_shifted())
        save_json_to_file(data, next_file_name)
        time.sleep(60)  # Check every 60 seconds

def func(batch_df, batch_id):
    #pandas_on_spark_df = pd.DataFrame(batch_df)
    batch_df.show()
    print(batch_df)

# Initialize Spark session
spark = SparkSession.builder.appName("EmbyStreamProcessing").getOrCreate()
spark.conf.set("spark.sql.streaming.schemaInterference", True)
data_init = call_emby_api()
save_json_to_file(data_init, './data/emby_data_02.json')
#items_init_df = spark.createDataFrame(data_init['Items'])
#selected_init_df = items_init_df.select("Id", "Name", "Type", "Date", "UserId")

schema = StructType([StructField('Items',ArrayType(StructType([StructField('Id',IntegerType(),True),
StructField('Name',StringType(),True),
StructField('ShortOverview',StringType(),True),
StructField('Type',StringType(),True),
StructField('Date',StringType(),True),
StructField('UserId',StringType(),True),
StructField('UserPrimaryImageTag',StringType(),True),
StructField('Severity',StringType(),True)])),True),
StructField('TotalRecordCount',IntegerType(),True)])




# Read the JSON file with the specified schema
json_df = spark.readStream.format("json").option("cleanSource","delete").option("multiline", "true").schema(schema).load("./data")
exploded_df = json_df.withColumn("ItemsListed", explode("Items"))
flattened_df = (
    exploded_df
    .drop("Items", "TotalRecordCount")
    .withColumn("Id", col("ItemsListed.Id"))
    .withColumn("Name", col("ItemsListed.Name"))
    .withColumn("Type", col("ItemsListed.Type"))
    .withColumn("Date", col("ItemsListed.Date"))
    .withColumn("UserId", col("ItemsListed.UserId"))
)

dummy_time_df = flattened_df.withColumn("processing_time", current_timestamp()).drop("ItemsListed")

processed_df = dummy_time_df.withWatermark("processing_time", "3 minutes")


trigger_file_path = "trigger_file.txt"
file_monitor_thread = threading.Thread(target=file_watchdog, args=(trigger_file_path,))
emby_monitor_thread = threading.Thread(target=emby_monitor)
#file_monitor_thread.start()
emby_monitor_thread.start()
# Print the results to the console
query = processed_df.writeStream.foreachBatch(func).start()
query.awaitTermination()
