import requests
import csv
import os

def get_movie_name(tmdb_id):
    # Check if English names file exists
    english_names_file = "movieEnglishName.csv"
    if os.path.exists(english_names_file):
        # Check if tmdb_id exists in the English names file
        with open(english_names_file, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['tmdb_id'] == str(tmdb_id):
                    return row['title']

    # Construct the TMDB API URL
    tmdb_api_url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key=b00a7e603d0290b2cf716cf341f382ea"

    # Send the GET request to TMDB API
    tmdb_response = requests.get(tmdb_api_url)

    # Check if the request was successful (status code 200)
    if tmdb_response.status_code != 200:
        # Return an error message
        return {"error": "Failed to get TMDB result"}

    # Extract the title from the response JSON
    tmdb_response_json = tmdb_response.json()
    title = tmdb_response_json.get('title', "")

    # Append the id and title to the English names file
    with open(english_names_file, mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow([tmdb_id, title])

    # Return the title
    return title

def get_tv_name(tmdb_id):
    # Check if English names file exists
    english_names_file = "TVEnglishName.csv"
    if os.path.exists(english_names_file):
        # Check if tmdb_id exists in the English names file
        with open(english_names_file, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['tmdb_id'] == str(tmdb_id):
                    return row['title']

    # Construct the TMDB API URL
    tmdb_api_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key=b00a7e603d0290b2cf716cf341f382ea"

    # Send the GET request to TMDB API
    tmdb_response = requests.get(tmdb_api_url)

    # Check if the request was successful (status code 200)
    if tmdb_response.status_code != 200:
        # Return an error message
        return {"error": "Failed to get TMDB result"}

    # Extract the title from the response JSON
    tmdb_response_json = tmdb_response.json()
    title = tmdb_response_json.get('name', "")

    # Append the id and title to the English names file
    with open(english_names_file, mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow([tmdb_id, title])

    # Return the title
    return title


