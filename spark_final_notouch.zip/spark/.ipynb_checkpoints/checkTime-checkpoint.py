from streamSubFunctions import *
from pyspark import SparkContext
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("EmbyStreamProcessing").getOrCreate()

print(emby_date_shifted())
data = call_emby_api("2024-04-30")
items = data.get("Items", [])
items_df = spark.createDataFrame(items)
selected_df = items_df.select("Id", "Name", "Type", "Date", "UserId")
selected_df.show(truncate=False)
spark.stop()
