# Import modules
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import split
import shutil
import re

# Create a spark session
spark = SparkContext("local", "myApp")

# Define a function to check if a string is a valid IP address
def is_ip(line):
    # Split the line into words
    words = line.split(" ")
    ip_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    return ip_pattern.match(words[0]) is not None
# Define a function to check if the last column of a line is an integer

def is_int(line):
  # Use a regular expression to match one or more digits at the end of the line
  pattern = r"\d+$"
  return bool(re.search(pattern, line))

# Get the first word as key, the last word as value, and cast it as integer
def get_key_and_value(line):
  # Split the line by spaces and get the first and last elements as strings
  words = line.split(" ")
  key = words[0]
  value = words[-1]
  # Try to cast the value to int or return None if it fails
  try:
    value = int(value)
  except ValueError:
    value = None
  # Return a tuple of key and value
  return (key, value)



# Read the log file and create rdd
log = spark.textFile("epa-http.txt")

# Filter out the domains
ipLog = log.filter(is_ip)
# Filter out invalid transmitted Bytes
filteredLog = ipLog.filter(is_int)

# Map the RDD to get key (IP) and value (Bytes)
key_value = filteredLog.map(get_key_and_value)

# Sum Bytes transmitted by the IP
sum_bytes = key_value.reduceByKey(lambda x, y: x + y)

# Sort the RDD by key in Byte descending order
sorted_rdd = sum_bytes.sortBy(lambda x: x[1], ascending=False)
top_100_rdd = sorted_rdd.take(100)
top_10_rdd = sorted_rdd.take(10)
formatted_rdd_100 = spark.parallelize(top_100_rdd)
formatted_rdd_10 = spark.parallelize(top_10_rdd)
# Delete the existing output directory if it exists
output_directory_0 = './HW1_2_top100.csv'
output_directory_1 = './HW1_2_top10.csv'
try:
    shutil.rmtree(output_directory_0)
except FileNotFoundError:
    pass
try:
    shutil.rmtree(output_directory_1)
except FileNotFoundError:
    pass
# Write the RDD to a CSV file
formatted_rdd_100.map(lambda x: f"{x[0]}, {x[1]}").saveAsTextFile("./HW1_2_top100.csv")
formatted_rdd_10.map(lambda x: f"{x[0]}, {x[1]}").saveAsTextFile("./HW1_2_top10.csv")

spark.stop()
