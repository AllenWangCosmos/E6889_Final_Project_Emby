from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import time
import numpy as np

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("FilterMoviesOperatorReordering") \
    .getOrCreate()

# Load the CSV file into a DataFrame
csv_file_path = "/mnt/data/movies.csv"  # Update the path if necessary
df = spark.read.csv(csv_file_path, header=True, inferSchema=True)

# Convert 'year' column to integer type if necessary
df = df.withColumn("year", col("year").cast("integer"))

# Number of times to run the filtering algorithm for averaging
num_runs = 10

# Define thresholds for filtering
rating_threshold = 7.0  # Example threshold for rating
year_threshold = 2000  # Example threshold for year

# Initialize lists to store execution times
times_rating_then_year = []
times_year_then_rating = []

# Run the filtering algorithm multiple times
for _ in range(num_runs):
    # Rating then Year
    start_time = time.time()
    df.filter(col("rating") >= rating_threshold).filter(col("year") >= year_threshold).count()
    end_time = time.time()
    times_rating_then_year.append(end_time - start_time)

    # Year then Rating
    start_time = time.time()
    df.filter(col("year") >= year_threshold).filter(col("rating") >= rating_threshold).count()
    end_time = time.time()
    times_year_then_rating.append(end_time - start_time)

# Calculate average execution times
avg_time_rating_then_year = np.mean(times_rating_then_year)
avg_time_year_then_rating = np.mean(times_year_then_rating)

print(f"Average execution time (Rating then Year): {avg_time_rating_then_year} seconds")
print(f"Average execution time (Year then Rating): {avg_time_year_then_rating} seconds")

# Stop the Spark session
spark.stop()
