# Import modules
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import split
import shutil
import re

# Create a spark session
spark = SparkContext("local", "myApp")

# Define a function to check if a string is a valid IP address
def is_ip(line):
    # Split the line into words
    words = line.split(" ")
    ip_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    return ip_pattern.match(words[0]) is not None
# Define a function to check if the last column of a line is an integer

def is_int(line):
  # Use a regular expression to match one or more digits at the end of the line
  pattern = r"\d+$"
  return bool(re.search(pattern, line))

# Get the first word as key, the last word as value, and cast it as integer
def get_key_and_value(line):
  # Split the line by spaces and get the first and last elements as strings
  words = line.split(" ")
  key = words[0]
  value = words[-1]
  # Try to cast the value to int or return None if it fails
  try:
    value = int(value)
  except ValueError:
    value = None
  # Return a tuple of key and value
  return (key, value)

def within_interval(line):
    # Regular expression pattern to extract the timestamp
    timestamp_pattern = re.compile(r'\[(\d+:\d+:\d+:\d+)\]')
    
    # Match the timestamp pattern
    match = timestamp_pattern.search(line)
    
    if match:
        timestamp = match.group(1)
        
        # Check if the timestamp is within the specified range [30:00:00:00 to 30:00:59:59]
        return "30:00:00:00" <= timestamp <= "30:00:59:59"
    
    return False

# Read the log file and create rdd
log = spark.textFile("epa-http.txt")

# Filter out the domains
ipLog = log.filter(is_ip)
# Filter out invalid transmitted Bytes
filteredLog = ipLog.filter(is_int)
withinTime = filteredLog.filter(within_interval)

# Map the RDD to get key (IP) and value (Bytes)
key_value = withinTime.map(get_key_and_value)

# Sum Bytes transmitted by the IP
sum_bytes = key_value.reduceByKey(lambda x, y: x + y)
final_rdd = sum_bytes.sortByKey(ascending=True)
output_directory = './HW1_3.csv'
try:
    shutil.rmtree(output_directory)
except FileNotFoundError:
    pass
# Write the RDD to a CSV file
final_rdd.map(lambda x: ", ".join(str(y) for y in x)).saveAsTextFile("./HW1_3.csv")

spark.stop()
