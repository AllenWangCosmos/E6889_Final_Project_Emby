from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.streaming import StreamingContext
import time
from pyspark.sql.functions import to_timestamp, col, current_timestamp, date_sub, lit, unix_timestamp, expr, regexp_extract, when, regexp_replace, explode
import requests
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib import cm
import pandas as pd
import numpy as np
import csv
from streamSubFunctions import *
from collections import Counter
import threading
import os

trigger_immediate_call = False

# Initialize SparkContext and SparkSession
sc = SparkContext("local[2]", "EmbyAPISparkStreaming")
spark = SparkSession(sc)

# Function to generate RDDs and enqueue them into the stream
def generate_rdds():
    while True:
        emby_json = call_emby_api(emby_date_shifted())
        emby_df = list(emby_json)
        yield sc.parallelize(emby_df)
        time.sleep(60)  # Sleep for 60 seconds before fetching data again

def process_rdd(rdd):
    global trigger_immediate_call
    print("process_rdd is running!")
    if not rdd.isEmpty():
        # Process the RDD as usual
        pd = rdd.toPandas()
        print(pd.head(3))
        # ...
        # Check if the trigger for immediate call is set
        if trigger_immediate_call:
            call_emby_api()  # Call the Emby API immediately
            trigger_immediate_call = False  # Reset the trigger

def file_watchdog(file_path):
    global trigger_immediate_call
    # Monitor the file for changes
    file_modification_time = os.path.getmtime(file_path)
    while True:
        current_modification_time = os.path.getmtime(file_path)
        if current_modification_time != file_modification_time:
            # File has been modified
            trigger_immediate_call = True
            print("Triggered!")
            file_modification_time = current_modification_time
        time.sleep(1)  # Check every second



# Create a local StreamingContext with batch interval of 60 seconds
ssc = StreamingContext(sc, 60)

file_path = "trigger_file.txt"
file_monitor_thread = threading.Thread(target=file_watchdog, args=(file_path,))
#file_monitor_thread.start()
# Create a DStream that represents streaming data (example: queueStream)


stream = ssc.queueStream(list(generate_rdds()))
stream.foreachRDD(process_rdd)
# Start the computation
ssc.start()
# Call the process_rdd function for each RDD in the stream

# Wait for the computation to terminate
ssc.awaitTermination()