import requests
from urllib.parse import urlencode
from tmdbMovieSearch import *

def search_item(name_starts_with):
    url = "https://gigasnow.synology.me:8921/emby/Items"
    recursive = "true"
    api_key = "11012a4a9c684ad4862c63db2acb83fa"

    # Construct the parameters
    params = {
        "Recursive": recursive,
        "SearchTerm": name_starts_with,
        "api_key": api_key,
        "Fields": "Genres,ProviderIds"
    }

    # Construct the final request URL
    final_url = url + "?" + urlencode(params)

    # Send the GET request
    response = requests.get(final_url)

    # Check if the request was successful (status code 200)
    if response.status_code != 200:
        # Return an error message
        return {"error": response.text}
    
    emby_response_json = response.json()
    filtered_items = [item for item in emby_response_json["Items"] if item["Type"] in ["Series", "Movie"]]

    # Check if there are any filtered items
    if filtered_items:
        # Choose the first filtered item
        chosen_item = filtered_items[0]
    else:
        return {"error": "No items found with Type 'Series' or 'Movie'"}
    # Extract information from the response JSON
    genres = chosen_item.get("Genres", [])
    tmdb_id = chosen_item["ProviderIds"].get("Tmdb", "")
    type = chosen_item.get("Type", "")
    if not tmdb_id:
        return {"error": "Failed to get TMDb ID"}
    if type == "Movie":
        title = get_movie_name(tmdb_id)
    else:
        title = get_tv_name(tmdb_id)
    # Return the extracted information as JSON format
    return {
        "type": type,
        "genres": genres,
        "tmdb_id": tmdb_id,
        "title": title
    }


