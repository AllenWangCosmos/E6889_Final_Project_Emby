from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, when
import time

# 初始化SparkSession
spark = SparkSession.builder.appName("OperatorSeparationMovies").getOrCreate()

# 加载数据
movies_df = spark.read.option("header", "true").csv("movies.csv")

# 函数：模拟聚合操作，有无操作符分离
def simulate_aggregation(rating_threshold, separated):
    start_time = time.time()

    if separated:
        # 操作符分离: 先过滤，然后聚合
        filtered_df = movies_df.filter(col("rating") >= rating_threshold)
        result = filtered_df.agg(avg(col("duration").cast("float"))).collect()
    else:
        # 不分离: 在聚合函数中应用条件
        result = movies_df.agg(avg(when(col("rating") >= rating_threshold, col("duration").cast("float")))).collect()

    end_time = time.time()
    runtime = end_time - start_time
    return runtime

# 测试不同的评分阈值
rating_thresholds = [7.0, 8.0, 9.0]  # 不同的阈值代表不同的选择性
for threshold in rating_thresholds:
    runtime_separated = simulate_aggregation(threshold, separated=True)
    runtime_not_separated = simulate_aggregation(threshold, separated=False)
    print(f"Rating Threshold: {threshold}, Separated Runtime: {runtime_separated:.4f} seconds, Not Separated Runtime: {runtime_not_separated:.4f} seconds")

# 结束Spark会话
spark.stop()
