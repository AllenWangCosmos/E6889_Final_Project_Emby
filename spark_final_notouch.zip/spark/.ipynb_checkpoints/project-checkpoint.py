# Import modules
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import split
import shutil
import re
import pandas as pd
import requests
from pyspark.sql import SparkSession

# Initialize Spark Session
spark = SparkSession.builder.appName("EmbyDataFetch").getOrCreate()

# Correct the EMBY_URL to point to the correct endpoint for fetching items
# Ensure this URL is correct and points to the API you want to use
EMBY_URL = 'https://gigasnow.synology.me:8921/emby/System/ActivityLog/Entries'
API_KEY = '11012a4a9c684ad4862c63db2acb83fa'

# Construct the API request URL
ITEMS_URL = f'{EMBY_URL}?api_key={API_KEY}&Limit=320'  # Adjust the query parameters as needed

# Fetch data from Emby API
response = requests.get(ITEMS_URL)

# Check if the response was successful
if response.status_code == 200:
    data = response.json()
    # Assuming `data` contains a list of items, and 'Items' is the correct key in the JSON
    if 'Items' in data:
        df = spark.createDataFrame(data['Items'])
        df.show()
    else:
        print("The 'Items' key was not found in the JSON response.")
else:
    print(f"Failed to fetch data from the API. Status code: {response.status_code}, URL: {ITEMS_URL}")

csv_file_path = "data.csv"
df.write.option("header", True).option("delimiter",",").csv(csv_file_path)

# Don't forget to stop the Spark session when done
spark.stop()