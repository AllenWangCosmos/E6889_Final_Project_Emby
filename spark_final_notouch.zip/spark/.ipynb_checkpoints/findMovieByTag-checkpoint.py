import requests

def find_movies_by_genre(genre_id):
    # Base URL
    base_url = "https://gigasnow.synology.me:8921/emby/Items"

    # Parameters
    params = {
        "IncludeItemTypes": "Movie,Series",
        "SortOrder": "Ascending",
        "IncludeItemTypes": "Movie",
        "GenreIds": genre_id,
        "Recursive": "true",
        "userId": "01167a66d7f34272b6d847fd34e4c07a",
        "X-Emby-Client": "Emby Web",
        "X-Emby-Device-Name": "Chromium macOS",
        "X-Emby-Device-Id": "dd7ce60e-6f44-4dad-aea7-46e4b29bbe7e",
        "X-Emby-Client-Version": "4.8.3.0",
        "api_key": "11012a4a9c684ad4862c63db2acb83fa",
        "X-Emby-Language": "en-gb",
        #"Limit": "2"
    }

    # Construct the final request URL
    url = base_url

    # Send the GET request
    response = requests.get(url, params=params)

    # Check if the request was successful (status code 200)
    if response.status_code != 200:
        # Print the response content
        print(response.text)

    # Parse the JSON response
    emby_response_json = response.json()

    # Extract movie and series names
    names = [item["Name"] for item in emby_response_json["Items"]]
    
    return names
    
def find_series_by_genre(genre_id):
    # Base URL
    base_url = "https://gigasnow.synology.me:8921/emby/Items"

    # Parameters
    params = {
        "IncludeItemTypes": "Movie,Series",
        "SortOrder": "Ascending",
        "IncludeItemTypes": "Series",
        "GenreIds": genre_id,
        "Recursive": "true",
        "userId": "01167a66d7f34272b6d847fd34e4c07a",
        "X-Emby-Client": "Emby Web",
        "X-Emby-Device-Name": "Chromium macOS",
        "X-Emby-Device-Id": "dd7ce60e-6f44-4dad-aea7-46e4b29bbe7e",
        "X-Emby-Client-Version": "4.8.3.0",
        "api_key": "11012a4a9c684ad4862c63db2acb83fa",
        "X-Emby-Language": "en-gb",
        #"Limit": "2"
    }

    # Construct the final request URL
    url = base_url

    # Send the GET request
    response = requests.get(url, params=params)

    # Check if the request was successful (status code 200)
    if response.status_code != 200:
        # Print the response content
        print(response.text)

    # Parse the JSON response
    emby_response_json = response.json()

    # Extract movie and series names
    names = [item["Name"] for item in emby_response_json["Items"]]
    
    return names

