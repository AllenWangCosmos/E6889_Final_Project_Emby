# Import modules
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import split
import shutil
import re
import pandas as pd

# Create a spark session
spark = SparkContext("local", "myApp")

# Define a function to check if a string is a valid IP address
def is_ip(line):
    # Split the line into words
    words = line.split(" ")
    ip_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    return ip_pattern.match(words[0]) is not None
# Define a function to check if the last column of a line is an integer

def is_int(line):
  # Use a regular expression to match one or more digits at the end of the line
  pattern = r"\d+$"
  return bool(re.search(pattern, line))

# Get the first word as key, the last word as value, and cast it as integer
def get_key_and_value(line):
  # Split the line by spaces and get the first and last elements as strings
  words = line.split(" ")
  key = words[0]
  value = words[-1]
  # Try to cast the value to int or return None if it fails
  try:
    value = int(value)
  except ValueError:
    value = None
  # Return a tuple of key and value
  return (key, value)



# Read the log file and create rdd
log = spark.textFile("epa-http.txt")

# Filter out the domains
ipLog = log.filter(is_ip)
# Filter out invalid transmitted Bytes
filteredLog = ipLog.filter(is_int)

# Map the RDD to get key (IP) and value (Bytes)
key_value = filteredLog.map(get_key_and_value)

# Sum Bytes transmitted by the IP
sum_bytes = key_value.reduceByKey(lambda x, y: x + y)

# Sort the RDD by key in string ascending order
final_rdd = sum_bytes.sortByKey(ascending=True)

# Delete the existing output directory if it exists
output_directory = './HW1_1.csv'
try:
    shutil.rmtree(output_directory)
except FileNotFoundError:
    pass
# Write the RDD to a CSV file
# .coalesce(1).saveAsTextFile("./HW1_1.csv")
#final_rdd.to_csv('./HW1_1.csv')

a = final_rdd.map(lambda x: x[0]).collect()
b = final_rdd.map(lambda x: x[1]).collect()
dataframe = pd.DataFrame({'IP':a, 'Bytes':b})
dataframe.to_csv("Q1.csv",index=False,sep=',')

spark.stop()
